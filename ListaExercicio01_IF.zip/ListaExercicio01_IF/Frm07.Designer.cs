﻿namespace ListaExercicio01_IF
{
    partial class Frm07
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnTestarF = new System.Windows.Forms.Button();
            this.txtPesoM = new System.Windows.Forms.TextBox();
            this.lblPesoM = new System.Windows.Forms.Label();
            this.lblQuestao = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtAlturaM = new System.Windows.Forms.TextBox();
            this.lblAlturaM = new System.Windows.Forms.Label();
            this.txtAlturaF = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btnCalcularF = new System.Windows.Forms.Button();
            this.txtPesoF = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnTestarF
            // 
            this.btnTestarF.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTestarF.Location = new System.Drawing.Point(109, 317);
            this.btnTestarF.Name = "btnTestarF";
            this.btnTestarF.Size = new System.Drawing.Size(105, 41);
            this.btnTestarF.TabIndex = 19;
            this.btnTestarF.Text = "CalcularM";
            this.btnTestarF.UseVisualStyleBackColor = true;
            this.btnTestarF.Click += new System.EventHandler(this.btnTestarF_Click);
            // 
            // txtPesoM
            // 
            this.txtPesoM.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPesoM.Location = new System.Drawing.Point(138, 174);
            this.txtPesoM.Name = "txtPesoM";
            this.txtPesoM.Size = new System.Drawing.Size(129, 31);
            this.txtPesoM.TabIndex = 18;
            // 
            // lblPesoM
            // 
            this.lblPesoM.AutoSize = true;
            this.lblPesoM.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPesoM.Location = new System.Drawing.Point(23, 180);
            this.lblPesoM.Name = "lblPesoM";
            this.lblPesoM.Size = new System.Drawing.Size(61, 25);
            this.lblPesoM.TabIndex = 17;
            this.lblPesoM.Text = "Peso";
            // 
            // lblQuestao
            // 
            this.lblQuestao.AutoSize = true;
            this.lblQuestao.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuestao.Location = new System.Drawing.Point(254, 23);
            this.lblQuestao.Name = "lblQuestao";
            this.lblQuestao.Size = new System.Drawing.Size(165, 37);
            this.lblQuestao.TabIndex = 16;
            this.lblQuestao.Text = "Questão 7";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(53, 105);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(161, 37);
            this.label1.TabIndex = 20;
            this.label1.Text = "Masculino";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(454, 105);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(149, 37);
            this.label2.TabIndex = 21;
            this.label2.Text = "Feminino";
            // 
            // txtAlturaM
            // 
            this.txtAlturaM.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAlturaM.Location = new System.Drawing.Point(138, 230);
            this.txtAlturaM.Name = "txtAlturaM";
            this.txtAlturaM.Size = new System.Drawing.Size(129, 31);
            this.txtAlturaM.TabIndex = 23;
            // 
            // lblAlturaM
            // 
            this.lblAlturaM.AutoSize = true;
            this.lblAlturaM.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAlturaM.Location = new System.Drawing.Point(23, 233);
            this.lblAlturaM.Name = "lblAlturaM";
            this.lblAlturaM.Size = new System.Drawing.Size(68, 25);
            this.lblAlturaM.TabIndex = 22;
            this.lblAlturaM.Text = "Altura";
            // 
            // txtAlturaF
            // 
            this.txtAlturaF.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAlturaF.Location = new System.Drawing.Point(516, 230);
            this.txtAlturaF.Name = "txtAlturaF";
            this.txtAlturaF.Size = new System.Drawing.Size(129, 31);
            this.txtAlturaF.TabIndex = 28;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(401, 233);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(68, 25);
            this.label3.TabIndex = 27;
            this.label3.Text = "Altura";
            // 
            // btnCalcularF
            // 
            this.btnCalcularF.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalcularF.Location = new System.Drawing.Point(487, 317);
            this.btnCalcularF.Name = "btnCalcularF";
            this.btnCalcularF.Size = new System.Drawing.Size(105, 41);
            this.btnCalcularF.TabIndex = 26;
            this.btnCalcularF.Text = "CalcularM";
            this.btnCalcularF.UseVisualStyleBackColor = true;
            this.btnCalcularF.Click += new System.EventHandler(this.btnCalcularF_Click);
            // 
            // txtPesoF
            // 
            this.txtPesoF.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPesoF.Location = new System.Drawing.Point(516, 174);
            this.txtPesoF.Name = "txtPesoF";
            this.txtPesoF.Size = new System.Drawing.Size(129, 31);
            this.txtPesoF.TabIndex = 25;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(401, 180);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(61, 25);
            this.label4.TabIndex = 24;
            this.label4.Text = "Peso";
            // 
            // Frm07
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txtAlturaF);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnCalcularF);
            this.Controls.Add(this.txtPesoF);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtAlturaM);
            this.Controls.Add(this.lblAlturaM);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnTestarF);
            this.Controls.Add(this.txtPesoM);
            this.Controls.Add(this.lblPesoM);
            this.Controls.Add(this.lblQuestao);
            this.Name = "Frm07";
            this.Text = "Frm07";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnTestarF;
        private System.Windows.Forms.TextBox txtPesoM;
        private System.Windows.Forms.Label lblPesoM;
        private System.Windows.Forms.Label lblQuestao;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtAlturaM;
        private System.Windows.Forms.Label lblAlturaM;
        private System.Windows.Forms.TextBox txtAlturaF;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnCalcularF;
        private System.Windows.Forms.TextBox txtPesoF;
        private System.Windows.Forms.Label label4;
    }
}